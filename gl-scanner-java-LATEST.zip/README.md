# Veracode Greenlight CI Tool

_Latest documentation always available at the [Veracode Help Center](https://help.veracode.com/reader/JVdG5ruGOiJnRpaJmQVCSQ/j_0qybfQ4hTEqrW1BkbhQQ)_

Scans source control (only Git currently) repository for changed & scannable files (only Java sources currently), and submits those changed files to Veracode Greenlight for analysis.

The only pre-requisites are Java 8 and the project being built (`gradle build` or `maven verify`, for example, has been run and the build outputs are available to the tool) before attempting to scan.

## About

The `gl-scanner-java` tool is designed to be used in a CI/CD pipeline to submit the contents of a Git commit to Veracode Greenlight for security scanning. It requires Java 8, access to the Git repository, and Veracode API Credentials for an account with Greenlight API access.

### Multi-commit Scanning

By default, this tool only looks at the last commit. If developers are pushing changes to the CI system for each commit, then this will capture all changes. However, many developers will make a number of commits, test them locally, and then push the set of commits to the CI system all at the same time. To see the changes in that set of commits, Greenlight has to find a previous commit to perform the comparison against. An easy way to do this is to query the CI system for the commit that was previously used in a successful pipeline. Some systems will provide this directly, while some require a bit of extra work.


#### Jenkins - Previous Successful Build Commit

Jenkins records the last commit that successfully built (`${env.GIT_PREVIOUS_SUCCESSFUL_COMMIT}`), and that can be passed directly to the tool via the `--previous_commit_hash` option. Any CI system that records the commit of a previous success build or pipeline can also use this option. You can also use this option in Gitlab if you prefer to find the previous commit yourself instead of letting the tool find it.

#### Gitlab - Previous Successful Scan Job Commit

Gitlab does not include previous build information in the environment, however, it does allow programmatic (REST) access to query previous pipelines for a lot of information, including all jobs. The tool knows how to query the Gitlab API to find the commit associated with the last successful run of a given job. In the Greenlight pipeline for the tool itself, we pass the `${CI_JOB_NAME}` variable to the `--previous_job_name` option to find the last successful Greenlight scan. This option also requires a Gitlab API token (can be generated at `https://your.gitlab-instance.org/profile/personal_access_tokens` by any user with read access to the project in question) to be passed to the `--gitlab_api_token` to access the Gitlab API.

### Scan Language

Using the Scan Language (`--scan_language`) option, either Java or JavaScript projects can have their files scanned. Java projects need to be built prior to scanning and the build outputs (at least .class intermediates) must be accessible by this tool. See the [Veracode Help Center](https://help.veracode.com/reader/JVdG5ruGOiJnRpaJmQVCSQ/diQCxK4tZKSyo1vRk8iKmA) for scannable JavaScript file types. JavaScript projects do not need to be built since the source files themselves are sent for scanning, and in fact, the build directory option (`--build_dir`) is ignored if specified. Only one project type can be scanned at a time: to scan projects with both Java and JS files, the tool will need to be run twice.

## Usage

The latest version will always be available at `https://downloads.veracode.com/securityscan/gl-scanner-java-LATEST.zip`. This ZIP file contains this README, and a single JAR (`gl-scanner-java.jar`) that contains all dependencies besides the required Java 8+ JVM.

Intended usage is to add a job to your CI/CD pipeline, after a build job, that downloads and unzips the tool, and then runs the JAR via `java -jar`. The status code returned depends on the results of the scan:

* If the tool finds no changed & scannable files, the tool returns a status code of 0, and the pipeline job should pass.
* If changed & scannable files are found, they will be submitted to the Greenlight service for scanning.
    * If no issues are found, the tool returns a status code of 0 and the pipeline should pass.
    * If issues are found, the tool returns a status code equal to the number of flaws found (up to 200), and the pipeline should fail.
    * If the scan fails (network issues, invalid API credentials, etc), the tool will return -1 and the pipeline should fail.

The tool will need some information passed to it as command line arguments (many are optional):

* Veracode API credentials (mandatory)
* Git commit to scan
* Source and build directories (For Java these directories store the .java and .class files. These directories are scanned recursively, therefore, you must specify them at the top of the package hierarchy. For JavaScript, the build directory is not needed or used.) 
* Excluded source directories
* Scan language: defaults to Java. JavaScript scanning is also available.
* Project info: will be included in results outputs and Greenlight usage reports
* Results customization: ignore issues of certain severities; display or hide details in the results summary
* Results output: Both summary and JSON can be shown on the console or dumped to disk, or disabled completely.

The default settings (supplying only the mandatory Veracode API Credentials) will direct the tool to:

* Scan the last Git commit (`HEAD`) and look for changed files in the Gradle default main java source (`src/main/java`) & build (`build/classes/java/main`) directories.
* Report issue counts for any Severity 1 or above issues.
* Display a summary of the results on the console.
* Write results JSON to storage, where it can then be manipulated (saved, processed, sent, etc) by the pipeline.



### Common Options

* `--project_[name|url|dir]` will be appended to the results JSON and summary outputs for easy organization. They can also included in any reports generated by Veracode for users.
* `--source_dir` and `--build_dir` are comma-separated lists of directories in which Greenlight looks for changed files and the build outputs for those files. (For Java these are .class files, and for JavaScript they are not required). Both directories are relative to the Git directory, which defaults to the current working directory.
* `--issue_counts=2:0,1:0,0:0` to only fail if Severity 3 or higher flaws are found.
* `--callback_url` can be used in asynchronous CI/CD pipelines by defining a URL where the results JSON will be `POST`ed upon completion of the scan.

#### Notes

When running the tool on JVM 9+, you may need to add `--add-modules java.xml.bind` to the `java` command (before the `-jar` option).

The available options also include the ability to scan arbitrary JARs (smaller than the Greenlight API size limit of 1 MB), and to analyze any existing results JSON file. These options are less useful in a CI/CD pipeline, but were useful during development and remain for flexibility.

## Examples

### Generic

To use in your own pipeline, include the JAR from the distribution ZIP (`https://downloads.veracode.com/securityscan/gl-scanner-java-LATEST.zip`) in your repository, add a pipeline job (after a build job!) that runs the JAR via `java -jar`, and passes the relevant parameters. If any flaws are found (not including any that are under the per-severity thresholds specified by the `--issue_counts` option), it will return a status code >=1 (this is the number of flaws found, up to 200), thus failing the pipeline job.

### Gitlab & Gradle

We use this structure in Gitlab CI to self-test, setting the `$VERACODE_API_*` variables in the CI/CD Settings

```
image: docker-image-with-jdk8-gradle-curl-unzip

stages:
  - build
  - greenlight

build_job:
  stage: build
  script:
    - gradle clean build
  artifacts:
    name: ${CI_PROJECT_NAME}_${CI_COMMIT_REF_NAME}_${CI_COMMIT_SHA}_build
    paths:
      - build/
    expire_in: 1 week
  
greenlight_job:
  stage: greenlight
  dependencies:
    - build_job
  artifacts:
    name: ${CI_PROJECT_NAME}_${CI_COMMIT_REF_NAME}_${CI_COMMIT_SHA}_greenlight-results
    paths:
      - results.json
    expire_in: 1 week
    when: always
  script:
    - curl -O https://downloads.veracode.com/securityscan/gl-scanner-java-LATEST.zip
    - unzip gl-scanner-java-LATEST.zip gl-scanner-java.jar
    - java -jar gl-scanner-java.jar
      --api_id "${VERACODE_API_ID}"
      --api_secret_key "${VERACODE_API_SECRET}"
      --source_dir "src/main/java"
      --build_dir "build/classes/java/main"
      --project_name "${CI_PROJECT_NAME}"
      --project_url "${CI_PROJECT_URL}"
      --project_ref "${CI_COMMIT_REF_NAME}"
      --previous_job_name "${CI_JOB_NAME}"
      --gitlab_api_token "${PRIVATE_TOKEN}"
``` 

### Gitlab & Maven

```
image: docker-image-with-jdk8-maven-curl-unzip

stages:
  - build
  - greenlight

build_job:
  stage: build
  script:
    - maven clean verify
  artifacts:
    name: ${CI_PROJECT_NAME}_${CI_COMMIT_REF_NAME}_${CI_COMMIT_SHA}_build
    paths:
      - build/
    expire_in: 1 week
  
greenlight_job:
  stage: greenlight
  dependencies:
    - build_job
  artifacts:
    name: ${CI_PROJECT_NAME}_${CI_COMMIT_REF_NAME}_${CI_COMMIT_SHA}_greenlight-results
    paths:
      - results.json
    expire_in: 1 week
    when: always
  script:
    - curl -O https://downloads.veracode.com/securityscan/gl-scanner-java-LATEST.zip
    - unzip gl-scanner-java-LATEST.zip gl-scanner-java.jar
    - java -jar gl-scanner-java.jar
      --api_id "${VERACODE_API_ID}"
      --api_secret_key "${VERACODE_API_SECRET}"
      --source_dir "src/main/java"
      --build_dir "target/classes"
      --project_name "${CI_PROJECT_NAME}"
      --project_url "${CI_PROJECT_URL}"
      --project_ref "${CI_COMMIT_REF_NAME}"
      --previous_job_name "${CI_JOB_NAME}"
      --gitlab_api_token "${PRIVATE_TOKEN}"
``` 

### Jenkins & Gradle

```
pipeline {
  agent any-with-jdk8-gradle-curl-unzip
  stages {
    stage('Gradle Build') {
      steps {
        - sh `gradle clean build`
      }
    }
    stage('Greenlight Scan') {
      steps {
        - sh `curl -O https://downloads.veracode.com/securityscan/gl-scanner-java-LATEST.zip`
        - sh `unzip gl-scanner-java-LATEST.zip gl-scanner-java.jar`
        - sh `java -jar gl-scanner-java.jar \
          --api_id "${VERACODE_API_ID}" \
          --api_secret_key "${VERACODE_API_SECRET}" \
          --source_dir "src/main/java" \
          --build_dir "build/classes/java/main" \
          --project_name "${env.JOB_NAME}" \
          --project_url "${env.JOB_URL}" \
          --project_ref "${env.GIT_COMMIT}" \
          --previous_commit_hash "${env.GIT_PREVIOUS_SUCCESSFUL_COMMIT}"`
      }
    }
  }
  post {
    always {
      archiveArtifacts artifacts: 'results.json', fingerprint: true
    }
  }
}
```

### Jenkins & Maven

```
pipeline {
  agent any-with-jdk8-maven-curl-unzip
  stages {
    stage('Maven Build') {
      steps {
        - sh 'maven clean verify'
      }
    }
    stage('Greenlight Scan') {
      steps {
        - sh `curl -O https://downloads.veracode.com/securityscan/gl-scanner-java-LATEST.zip`
        - sh `unzip gl-scanner-java-LATEST.zip gl-scanner-java.jar`
        - sh `java -jar gl-scanner-java.jar \
          --api_id "${VERACODE_API_ID}" \
          --api_secret_key "${VERACODE_API_SECRET}" \
          --source_dir "src/main/java" \
          --build_dir "target/classes" \
          --project_name "${env.JOB_NAME}" \
          --project_url "${env.JOB_URL}" \
          --project_ref "${env.GIT_COMMIT}" \
          --previous_commit_hash "${env.GIT_PREVIOUS_SUCCESSFUL_COMMIT}"`
      }
    }
  }
  post {
    always {
      archiveArtifacts artifacts: 'results.json', fingerprint: true
    }
  }
}
```

### JavaScript

Here is an example command line for scanning a simple JavaScript project, with all scannable files under the directory `src`, using the `--scan_language` option. You do not need to specify the build directory because Greenlight scans the source itself for JS scans.

_Note: If your project contains both Java and JavaScript, you currently must run two separate scans, one per language. If the `--scan_language` option is not provided, the tool will default to Java._

```
java -jar gl-scanner-java.jar \
--api_id "${VERACODE_API_ID}" \
--api_secret_key "${VERACODE_API_SECRET}" \
--scan_language js \
--source_dir src \
--project_name "${CI_PROJECT_NAME}" \
--project_url "${CI_PROJECT_URL}" \
--project_ref "${CI_COMMIT_REF_NAME}"
```

## Example Summary Output

### Default Summary

```
COMMIT-HASH: a11a20787e77beb305448387c6972e60a2c4fa07
====================
Analysis Successful!
====================
=======================
9 Best Practices found!
=======================
CWE-338: Use of Cryptographically Weak Pseudo-Random Number Generator (PRNG): flawedpackage/Greenlights.java:9
CWE-331: Insufficient Entropy: flawedpackage/Greenlights.java:9
CWE-326: Inadequate Encryption Strength: flawedpackage/GreenLightKeySizeHMAC.java:17
CWE-326: Inadequate Encryption Strength: flawedpackage/GreenLightKeySizeHMAC.java:33
CWE-327: Use of a Broken or Risky Cryptographic Algorithm: flawedpackage/Flawed.java:62
CWE-327: Use of a Broken or Risky Cryptographic Algorithm: flawedpackage/Flawed.java:63
CWE-327: Use of a Broken or Risky Cryptographic Algorithm: flawedpackage/Flawed.java:64
CWE-338: Use of Cryptographically Weak Pseudo-Random Number Generator (PRNG): flawedpackage/Flawed.java:73
CWE-331: Insufficient Entropy: flawedpackage/Flawed.java:73
======================
Found 11 total issues!
======================
----------------------------------------------
Found 2 issues of Severity 2 - Low. (Threshold is 1)
----------------------------------------------
CWE-597: Use of Wrong Operator in String Comparison: flawedpackage/OneFlaw.java:5
CWE-404: Improper Resource Shutdown or Release: flawedpackage/Flawed.java:37
----------------------------------------------
Found 7 issues of Severity 3 - Medium. (Threshold is 1)
----------------------------------------------
CWE-326: Inadequate Encryption Strength: flawedpackage/GreenLightKeySizeHMAC.java:38
CWE-259: Use of Hard-coded Password: flawedpackage/Flawed.java:23
CWE-259: Use of Hard-coded Password: flawedpackage/Flawed.java:54
CWE-331: Insufficient Entropy: flawedpackage/Flawed.java:59
CWE-327: Use of a Broken or Risky Cryptographic Algorithm: flawedpackage/Flawed.java:60
CWE-327: Use of a Broken or Risky Cryptographic Algorithm: flawedpackage/Flawed.java:61
CWE-326: Inadequate Encryption Strength: flawedpackage/Flawed.java:68
----------------------------------------------
Found 1 issues of Severity 4 - High. (Threshold is 1)
----------------------------------------------
CWE-89: Improper Neutralization of Special Elements used in an SQL Command ('SQL Injection'): flawedpackage/Flawed.java:43
----------------------------------------------
Found 1 issues of Severity 5 - Very High. (Threshold is 1)
----------------------------------------------
CWE-78: Improper Neutralization of Special Elements used in an OS Command ('OS Command Injection'): flawedpackage/Flawed.java:50
============================================
FAILURE: Found 11 issues, hit the threshold!
============================================
```

### Best Practices Collapsed

Using `--best_practices false`

```
COMMIT-HASH: be902bee2d49026178fbf72aba50aa86077258eb
====================
Analysis Successful!
====================
=======================
2 Best Practices found!
=======================
=====================
Found 1 total issues!
=====================
----------------------------------------------
Found 1 issues of Severity 2 - Low. (Threshold is 1)
----------------------------------------------
CWE-597: Use of Wrong Operator in String Comparison: flawedpackage/OneFlaw.java:5
===========================================
FAILURE: Found 1 issues, hit the threshold!
===========================================
```

### Issue Details Expanded

Using `--issue_details true`

```
COMMIT-HASH: be902bee2d49026178fbf72aba50aa86077258eb
====================
Analysis Successful!
====================
=======================
2 Best Practices found!
=======================
CWE-338: Use of Cryptographically Weak Pseudo-Random Number Generator (PRNG): flawedpackage/Greenlights.java:9
Details: <span>This is an acceptably strong pseudorandom number generator (PRNG) for cryptographic usage.</span> <span>This is not a flaw. No fix required.</span> <span>References: <a href="http://cwe.mitre.org/data/definitions/338.html">CWE</a></span>
CWE-331: Insufficient Entropy: flawedpackage/Greenlights.java:9
Details: <span>This is an acceptably strong pseudorandom number generator (PRNG) for cryptographic usage.</span> <span>This is not a flaw. No fix required.</span> <span>References: <a href="http://cwe.mitre.org/data/definitions/331.html">CWE</a></span>
=====================
Found 1 total issues!
=====================
----------------------------------------------
Found 1 issues of Severity 2 - Low. (Threshold is 1)
----------------------------------------------
CWE-597: Use of Wrong Operator in String Comparison: flawedpackage/OneFlaw.java:5
Details: <span>Using '==' to compare two strings for equality actually compares the object references rather than their values.  It is unlikely that this reflects the intended application logic.</span> <span>Use the equals() method to compare strings, not the '==' operator.</span> <span>References: <a href="http://cwe.mitre.org/data/definitions/597.html">CWE</a></span>
===========================================
FAILURE: Found 1 issues, hit the threshold!
===========================================
```

### Custom Threshold

Using `--issue_counts 2:0,1:0,0:0`

```
COMMIT-HASH: be902bee2d49026178fbf72aba50aa86077258eb
====================
Analysis Successful!
====================
=======================
2 Best Practices found!
=======================
CWE-338: Use of Cryptographically Weak Pseudo-Random Number Generator (PRNG): flawedpackage/Greenlights.java:9
CWE-331: Insufficient Entropy: flawedpackage/Greenlights.java:9
=====================
Found 1 total issues!
=====================
-------------------------------------------------
Skipping 1 issues of Severity 2 - Low. (Threshold is 0)
-------------------------------------------------
===========================================
SUCCESS: All issue counts under thresholds!
===========================================
```


## Command Line Arguments Details

```
usage: java -jar gl-scanner-java.jar
       [-h] [-v] -i API_ID -k API_SECRET_KEY [-gt GITLAB_API_TOKEN] [-sl {java,js}] [-g GIT_DIR]
       [-s SOURCE_DIR] [-x EXCLUDE] [-b BUILD_DIR] [-p PROJECT_NAME] [-u PROJECT_URL] [-r PROJECT_REF]
       [-op {true,false}] [-ic ISSUE_COUNTS] [-cb CALLBACK_URL] [-id {true,false}] [-bp {true,false}]
       [-sd {true,false}] [-so {true,false}] [-sf SUMMARY_OUTPUT_FILE] [-jd {true,false}] [-jo {true,false}]
       [-jf JSON_OUTPUT_FILE] [-sj {true,false}] [-c COMMIT_HASH | -j JAR | -a {true,false}]
       [-pc PREVIOUS_COMMIT_HASH | -pj PREVIOUS_JOB_NAME]

Scan a source control commit (defaults to last commit)  with Veracode Greenlight. Optionally, scan a pre-built JAR
with Veracode Greenlight.

Results JSON will always be output to file storage.  A  human-readable summary will also be output to file storage
if the results contain any findings.

Either or both can also be displayed on the console  as well, see the help [-h] for details. Adding '-Dgreenlight.
debug=true' to the java command will increase verbosity of the console output.

named arguments:
  -h, --help             Show this help message and exit.
  -v, --version          Display version info and exit.

API Credentials:
  -i API_ID, --api_id API_ID
                         Veracode API ID
  -k API_SECRET_KEY, --api_secret_key API_SECRET_KEY
                         Veracode API Secret Key
  -gt GITLAB_API_TOKEN, --gitlab_api_token GITLAB_API_TOKEN
                         Gitlab API  access  token.  Needed  to  find  previous  job  and  associated  commit  for
                         comparison.

Actions:
  Optional, pick one: Defaults to 'HEAD' using Git 'HEAD'.

  -c COMMIT_HASH, --commit_hash COMMIT_HASH
                         Scans changed files in the specified commit. (default: HEAD)
  -j JAR, --jar JAR      Scans the specified pre-existing JAR.
  -a {true,false}, --analyze_only {true,false}
                         Only analyze existing results JSON file  (as specified by '--json_output_file'). Does not
                         check Git status nor upload anything. (default: false)

Previous Commit:
  Optional: Choose Strategy for finding a previous commit for comparing to find scannable files

  -pc PREVIOUS_COMMIT_HASH, --previous_commit_hash PREVIOUS_COMMIT_HASH
                         Previous commit hash to use a basis  for  comparing  to the specified commit. Defaults to
                         the current commit's parent[s].
  -pj PREVIOUS_JOB_NAME, --previous_job_name PREVIOUS_JOB_NAME
                         CI Job name to check for commit has of last successful run.

Scan Language:
  Choose which type of files to check for changes and potentially submit for scanning.

  -sl {java,js}, --scan_language {java,js}
                         * 'java' looks for changes  in  .java  files  and  submits  the matching .class files for
                         scanning.
                         * 'js' looks for changes in many  JavaScript-related file types and submits them directly
                         for scanning. Details on the scannable  Javascript-like  file  types  can be found in the
                         Veracode Help Center. (default: java)

Directories:
  Optional: Defaults to Git repo in  current  directory,  and  source  &  build as Gradle default directories. Not
  needed for scanning a JAR.

  -g GIT_DIR, --git_dir GIT_DIR
                         Git repository directory (default: .)
  -s SOURCE_DIR, --source_dir SOURCE_DIR
                         Source code  directories,  comma-separated,  relative  to  the  Git  directory. (default:
                         src/main/java)
  -x EXCLUDE, --exclude EXCLUDE
                         Regular Expression applied to source filename  &  path  that will ignore any source files
                         that match. Example: '-x "*Test.java"' will ignore  any  changed files that end in "Test.
                         java".
  -b BUILD_DIR, --build_dir BUILD_DIR
                         Build output directories, comma-separated, relative to  the Git directory. Note that when
                         scanning multiple directories,the results  may  not  prepend  the  build directory to the
                         filename, possibly causing flaw location ambiguity. (default: build/classes/java/main)

Project Info:
  Optional: Details about the project. Will be attached  to  the  results  summary and results JSON, and stored on
  the Greenlight backend for reporting purposes.

  -p PROJECT_NAME, --project_name PROJECT_NAME
                         Project name
  -u PROJECT_URL, --project_url PROJECT_URL
                         Source control URI
  -r PROJECT_REF, --project_ref PROJECT_REF
                         Source control ref/revision/branch

Miscellaneous:
  Optional: Misc options.

  -op {true,false}, --oversize_pass {true,false}
                         Do not fail the build if the  commit  creates  an  upload  file or package that is larger
                         than the Greenlight upload size limit. (default: false)
  -ic ISSUE_COUNTS, --issue_counts ISSUE_COUNTS
                         Set analysis to fail for Y issues of  Severity  X.  Use 0 (zero) to ignore issues of that
                         severity. May specify as few  Severity  levels  as  needed:  missing levels will keep the
                         defaults. Example: '--issue_counts=2:0,1:0,0:0"' would  ignore  any  flaws below Severity
                         3. The default is to fail on 1 or more issues at Severity 1 or above.
                          (default: 5:1,4:1,3:1,2:1,1:1,0:0)
  -cb CALLBACK_URL, --callback_url CALLBACK_URL
                         URL that results JSON will be POSTed to.
  -id {true,false}, --issue_details {true,false}
                         Show detailed messages for each issue in the results summary. (default: false)
  -bp {true,false}, --best_practices {true,false}
                         List the Best Practices Issues in  the  results  summary. This respects the above setting
                         regarding issue details. (default: true)
  -sd {true,false}, --summary_display {true,false}
                         Show human-readable results summary on the console. (default: true)
  -so {true,false}, --summary_output {true,false}
                         Save human-readable results summary to file. (default: false)
  -sf SUMMARY_OUTPUT_FILE, --summary_output_file SUMMARY_OUTPUT_FILE
                         Filename (in the current directory) to save results summary. (default: results.txt)
  -jd {true,false}, --json_display {true,false}
                         Show the results JSON on the console. (default: false)
  -jo {true,false}, --json_output {true,false}
                         Save results JSON to file. (default: true)
  -jf JSON_OUTPUT_FILE, --json_output_file JSON_OUTPUT_FILE
                         Filename (in the current directory) to save results JSON. (default: results.json)
  -sj {true,false}, --save_jar {true,false}
                         Set true to save the intermediate JAR for debugging. (default: false)
```

## Greenlight Common Options

These options are shared with the Greenlight plugins that run on the JVM. They are passed directly to the java command.

### Debug logging

* `greenlight.debug`
  * Example: `-Dgreenlight.debug=true`
  * Enables additional debug logging for more details about what the Greenlight plugin is doing.
